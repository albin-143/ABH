# ABH Downloader

A starter Android WebView browser project with:
- address/search bar
- bookmarks
- download list via Android DownloadManager
- long-press link/image download prompt
- desktop user-agent toggle
- basic settings
- GitHub Actions workflow to build a debug APK

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload all files in this project (including `.github/workflows/build-apk.yml`).
3. Open **Actions** → **Build ABH Downloader APK** → **Run workflow**.
4. When complete, open the workflow run and download the **ABH-Downloader-APK** artifact.
5. Extract it and install `app-debug.apk` on Android. You may need to allow installation from that source.

## Important limitations in this starter
- This is a WebView browser, not a full Chrome replacement.
- The quality chooser is a prompt only. It cannot manufacture 360p/720p/1080p variants. The website must expose a direct URL for the selected quality.
- YouTube does not expose ordinary downloadable video URLs to WebView. This app does not bypass YouTube restrictions or DRM; use YouTube's supported offline/download options where available.
- Long-press downloads direct links and images. Recursive website-folder crawling and preserving nested website folder structures are not implemented in this starter.
- Multiple tabs are currently a simple new-tab action that opens a fresh page; a full tab switcher is a future enhancement.

For a production release, add app signing, a proper tab manager, robust permission/error handling, and site-specific supported download integrations.
