package com.abh.downloader

import android.app.*
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.provider.OpenableColumns
import android.text.InputType
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("abh", MODE_PRIVATE) }
    private var desktop = false
    private var tabCount = 1
    private var currentUrl = "https://www.google.com"
    private val bookmarks get() = prefs.getStringSet("bookmarks", emptySet())!!.toMutableSet()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        load(currentUrl)
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8); gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "Search or enter website"
            singleLine = true
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setTextColor(Color.BLACK)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { navigate(text.toString()); true } else false
            }
        }
        top.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(makeButton("GO") { navigate(address.text.toString()) })
        outer.addView(top)
        status = TextView(this).apply { text = "ABH Downloader"; textSize = 11f; setPadding(10,2,10,2); setTextColor(Color.DKGRAY) }
        outer.addView(status)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                if (url != null) { currentUrl = url; address.setText(url); status.text = "Loading…" }
            }
            override fun onPageFinished(view: WebView?, url: String?) { status.text = "ABH Downloader • Ready" }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                return true
            }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            askDownload(url, contentDisposition, mimeType)
        }
        web.setOnLongClickListener {
            val hit = web.hitTestResult
            val target = when (hit.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> hit.extra
                WebView.HitTestResult.IMAGE_TYPE -> hit.extra
                else -> null
            }
            if (!target.isNullOrBlank() && (target.startsWith("http://") || target.startsWith("https://"))) {
                AlertDialog.Builder(this).setTitle("ABH Downloader")
                    .setItems(arrayOf("Download", "Open link")) { _, which ->
                        if (which == 0) askDownload(target, null, null) else load(target)
                    }.show()
                true
            } else false
        }
        outer.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(2,4,2,4)
        }
        listOf(
            "Back" to { if (web.canGoBack()) web.goBack() },
            "★" to { addBookmark() },
            "Bookmarks" to { showBookmarks() },
            "Downloads" to { showDownloads() },
            "+ Tab" to { tabCount++; navigate("https://www.google.com"); status.text = "Tab $tabCount" },
            "Desktop" to { desktop = !desktop; applyDesktop(); status.text = if (desktop) "Desktop mode ON" else "Mobile mode ON" },
            "Settings" to { showSettings() }
        ).forEach { (label, action) -> bar.addView(makeButton(label, action), LinearLayout.LayoutParams(0, 44, 1f)) }
        outer.addView(bar)
        setContentView(outer)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; minWidth = 0; minimumWidth = 0; setPadding(2,0,2,0)
        setOnClickListener { action() }
    }

    private fun navigate(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("http://") || value.startsWith("https://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=" + Uri.encode(value)
        }
        load(url)
    }
    private fun load(url: String) { currentUrl = url; address.setText(url); web.loadUrl(url) }

    private fun applyDesktop() {
        val ua = if (desktop)
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
        else WebSettings.getDefaultUserAgent(this)
        web.settings.userAgentString = ua
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.reload()
    }

    private fun addBookmark() {
        val set = bookmarks
        set.add(currentUrl)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }
    private fun showBookmarks() {
        val items = bookmarks.toTypedArray()
        if (items.isEmpty()) { toast("No bookmarks yet"); return }
        AlertDialog.Builder(this).setTitle("Bookmarks").setItems(items) { _, which -> load(items[which]) }
            .setNegativeButton("Close", null).show()
    }
    private fun showDownloads() {
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val c = dm.query(DownloadManager.Query())
        val lines = ArrayList<String>()
        if (c != null) {
            while (c.moveToNext()) {
                val name = c.getString(c.getColumnIndex(DownloadManager.COLUMN_TITLE))
                val state = c.getInt(c.getColumnIndex(DownloadManager.COLUMN_STATUS))
                lines.add("$name — ${if (state == DownloadManager.STATUS_SUCCESSFUL) "✓ Downloaded" else if (state == DownloadManager.STATUS_FAILED) "Failed" else "In progress"}")
            }
            c.close()
        }
        AlertDialog.Builder(this).setTitle("Downloaded files")
            .setItems(lines.toTypedArray().ifEmpty { arrayOf("No downloads yet") }) { _, _ -> }
            .setPositiveButton("OK", null).show()
    }

    private fun askDownload(url: String, disposition: String?, mime: String?) {
        val choices = arrayOf("Original quality / file", "360p (if provided by website)", "480p (if provided by website)", "720p HD (if provided by website)", "1080p (if provided by website)")
        AlertDialog.Builder(this).setTitle("Choose download quality")
            .setItems(choices) { _, which ->
                // WebView supplies a direct media/file URL. Quality variants must be exposed by the site itself.
                startDownload(url, disposition, mime)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun startDownload(url: String, disposition: String?, mime: String?) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setAllowedOverMetered(true)
            request.setAllowedOverRoaming(false)
            request.setTitle(URLUtil.guessFileName(url, disposition, mime))
            request.setDescription("Downloading with ABH Downloader")
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                "ABH Downloader/" + URLUtil.guessFileName(url, disposition, mime))
            val cookie = CookieManager.getInstance().getCookie(url)
            if (!cookie.isNullOrBlank()) request.addRequestHeader("Cookie", cookie)
            request.addRequestHeader("User-Agent", web.settings.userAgentString)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            toast("Download started")
        } catch (e: Exception) { toast("Download failed: ${e.message}") }
    }

    private fun showSettings() {
        val options = arrayOf("Clear browsing cache", "Clear bookmarks", "About ABH Downloader")
        AlertDialog.Builder(this).setTitle("Settings").setItems(options) { _, which ->
            when (which) {
                0 -> { web.clearCache(true); toast("Cache cleared") }
                1 -> { prefs.edit().remove("bookmarks").apply(); toast("Bookmarks cleared") }
                2 -> AlertDialog.Builder(this).setMessage("ABH Downloader 1.0\nA lightweight WebView browser with Android file downloads.").setPositiveButton("OK", null).show()
            }
        }.show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
