# ABH Downloader 2.0
Redesigned Android WebView browser starter project.

Implemented: custom ABH dark/blue interface, launcher icon artwork, web search/address bar, basic multiple tabs and tab switcher, bookmarks, direct-file downloads, download list with ✓✓ on completed downloads, long-press direct link/image actions, desktop user-agent toggle, settings/about.

Build: upload the CONTENTS of this folder to the root of a GitHub repository (not this ZIP), commit to main, open Actions and run Build ABH Downloader APK, then download artifact ABH-Downloader-APK-v2.

Honest limitations: YouTube does not expose ordinary downloadable media URLs to WebView; this app does not bypass YouTube protections or DRM. Use YouTube's official offline feature. Quality selection requires sites to expose separate direct quality URLs and is not implemented here. Generic recursive website-folder downloads are not implemented because many sites do not expose real folder listings. This is a functional starter browser, not a production browser.


## Download and quality behavior in this revision

- Direct HTTP/HTTPS file links use Android DownloadManager.
- Long-press an exposed HTML5 video or direct video link to list source URLs detected in the page.
- Only qualities the website actually exposes are offered; the app cannot manufacture 360p/720p/1080p/4K versions.
- DRM-protected streams, hidden adaptive manifests, and YouTube protected delivery are not bypassed.
- A normal website navigation link is not a folder. Recursive folder download requires a public directory-index page and is not guaranteed for arbitrary websites.
