package com.abh.downloader

import android.app.*
import android.os.Bundle
import android.os.Environment
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.content.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val bgColor = Color.rgb(13, 21, 40)
    private val card = Color.rgb(27, 40, 66)
    private val blue = Color.rgb(76, 126, 245)
    private val prefs by lazy { getSharedPreferences("abh", MODE_PRIVATE) }
    private val tabs = mutableListOf("https://www.google.com")
    private var active = 0
    private var desktop = false
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var tabCount: TextView
    private lateinit var frame: FrameLayout
    private val pageVideoSources = mutableListOf<Pair<String, String>>()

    private inner class VideoBridge {
        @JavascriptInterface
        fun onSources(json: String) {
            try {
                val arr = JSONArray(json)
                val found = mutableListOf<Pair<String, String>>()
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val url = item.optString("url")
                    val label = item.optString("label", "Available video")
                    if (url.startsWith("http") && found.none { it.first == url }) found.add(url to label)
                }
                runOnUiThread {
                    pageVideoSources.clear()
                    pageVideoSources.addAll(found)
                }
            } catch (_: Exception) { }
        }
    }

    private fun shape(color:Int, radius:Float=16f) = GradientDrawable().apply { setColor(color); cornerRadius=radius }
    private fun label(s:String, size:Float, color:Int, bold:Boolean=false) = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD)
    }
    private fun action(s:String, fn:()->Unit, primary:Boolean=false) = label(s,13f,Color.WHITE,true).apply {
        gravity=Gravity.CENTER; setPadding(13,12,13,12); background=shape(if(primary) blue else card); setOnClickListener{fn()}
    }

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply { orientation=1; setPadding(14,14,14,6); setBackgroundColor(bgColor) }
        val head=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        head.addView(label("ABH",24f,Color.WHITE,true).apply { gravity=Gravity.CENTER; background=shape(blue,14f) },LinearLayout.LayoutParams(58,48))
        val title=LinearLayout(this).apply { orientation=1; setPadding(10,0,0,0) }
        title.addView(label("ABH Downloader",19f,Color.WHITE,true))
        title.addView(label("Browse • Save • Organize",11f,0xFF9AAAC8.toInt()))
        head.addView(title,LinearLayout.LayoutParams(0,-2,1f))
        tabCount=label("1 TAB",11f,Color.WHITE,true).apply { background=shape(card,30f); setPadding(12,9,12,9) }
        head.addView(tabCount); root.addView(head)
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(0,14,0,8) }
        address=EditText(this).apply {
            hint="Search or enter website"; setSingleLine(true); textSize=14f
            setTextColor(Color.WHITE); setHintTextColor(0xFF9AAAC8.toInt()); background=shape(card)
            setPadding(13,0,8,0); inputType=android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions=EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, a, _ -> if(a==EditorInfo.IME_ACTION_GO){go(text.toString());true}else false }
        }
        row.addView(address,LinearLayout.LayoutParams(0,50,1f))
        val goBtn=action("GO",{go(address.text.toString())},true)
        val gp=LinearLayout.LayoutParams(58,50); gp.leftMargin=7; row.addView(goBtn,gp); root.addView(row)
        frame=FrameLayout(this); root.addView(frame,LinearLayout.LayoutParams(-1,0,1f))
        web=WebView(this).apply {
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true

            // Mobile layout by default, with pinch-to-zoom enabled.
            settings.useWideViewPort=true
            settings.loadWithOverviewMode=false
            settings.setSupportZoom(true)
            settings.builtInZoomControls=true
            settings.displayZoomControls=false
            settings.textZoom=100
            addJavascriptInterface(VideoBridge(), "ABHVideoBridge")
            webViewClient=object:WebViewClient(){
                override fun onPageStarted(v:WebView?,u:String?,f:android.graphics.Bitmap?){
                    pageVideoSources.clear()
                    u?.let{tabs[active]=it;address.setText(it)}
                }
                override fun onPageFinished(v:WebView?, url: String?) {
                    val script = """
                        (function(){
                          try {
                            var out=[];
                            document.querySelectorAll('video').forEach(function(v){
                              var nodes=[];
                              if(v.currentSrc) nodes.push({src:v.currentSrc,h:(v.videoHeight||0)});
                              if(v.src) nodes.push({src:v.src,h:(v.videoHeight||0)});
                              v.querySelectorAll('source').forEach(function(s){
                                nodes.push({src:s.src,h:parseInt(s.getAttribute('height')||'0')||0});
                              });
                              nodes.forEach(function(n){
                                if(n.src && /^https?:/.test(n.src)){
                                  out.push({url:n.src,label:n.h ? (n.h+'p') : 'Available video'});
                                }
                              });
                            });
                            window.ABHVideoBridge.onSources(JSON.stringify(out));
                          } catch(e) {}
                        })();
                    """.trimIndent()
                    v?.evaluateJavascript(script, null)
                }
            }
            setDownloadListener { u,ua,cd,m,_ -> askDownload(u,ua,cd,m) }
            setOnLongClickListener {
                val h: WebView.HitTestResult = hitTestResult
                val u = h.extra
                when {
                    u != null && h.type in listOf(
                        WebView.HitTestResult.SRC_ANCHOR_TYPE,
                        WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE,
                        WebView.HitTestResult.IMAGE_TYPE,
                    ) -> {
                        if (looksLikeVideo(u)) showVideoQualityOptions(u)
                        else AlertDialog.Builder(this@MainActivity)
                            .setTitle("ABH • Link actions")
                            .setItems(arrayOf("Download link / image", "Open link")) { _, n ->
                                if (n == 0) askDownload(u, settings.userAgentString, null, null) else go(u)
                            }.show()
                        true
                    }
                    pageVideoSources.isNotEmpty() -> {
                        showVideoQualityOptions(null)
                        true
                    }
                    else -> false
                }
            }
        }
        frame.addView(web)
        val nav=LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(0,8,0,0) }
        listOf("⌂\nHome","☆\nBookmarks","↓\nDownloads","▢\nTabs","•••\nMore").forEachIndexed { i,s ->
            val t=label(s,11f,0xFFD5DFF2.toInt(),true).apply { gravity=Gravity.CENTER; setPadding(2,8,2,8); setOnClickListener{
                when(i){0->go("https://www.google.com");1->bookmarks();2->downloads();3->tabsDialog();4->more()}
            }}
            nav.addView(t,LinearLayout.LayoutParams(0,52,1f))
        }
        root.addView(nav); setContentView(root); go(tabs[0])
    }
    private fun go(raw:String){
        val s=raw.trim(); if(s.isEmpty())return
        val u=when{ s.startsWith("http://")||s.startsWith("https://")->s; s.contains(".")&&!s.contains(" ")->"https://$s"; else->"https://www.google.com/search?q="+Uri.encode(s)}
        tabs[active]=u; address.setText(u); web.loadUrl(u); tabCount.text="${tabs.size} TAB${if(tabs.size==1) "" else "S"}"
    }
    private fun tabsDialog(){
        val opts=(tabs.mapIndexed{i,u->"${if(i==active) "● " else ""}${i+1}. ${u.take(55)}"}+ "＋ New tab").toTypedArray()
        AlertDialog.Builder(this).setTitle("Tabs").setItems(opts){_,n->if(n==tabs.size){tabs.add("https://www.google.com");active=tabs.lastIndex;go(tabs[active])}else{active=n;go(tabs[n])}}.setNegativeButton("Close current"){_,_->if(tabs.size>1){tabs.removeAt(active);active=(active-1).coerceAtLeast(0);go(tabs[active])}}.show()
    }
    private fun saved():MutableList<String>{
        val out=mutableListOf<String>();try{val a=JSONArray(prefs.getString("bookmarks","[]"));for(i in 0 until a.length())out.add(a.getString(i))}catch(_:Exception){};return out
    }
    private fun bookmarks(){
        val b=saved();val opts=(b+"＋ Save current page").toTypedArray()
        AlertDialog.Builder(this).setTitle("Bookmarks").setItems(opts){_,n->
            if(n==b.size){val u=web.url?:return@setItems;if(!b.contains(u))b.add(u);prefs.edit().putString("bookmarks",JSONArray(b).toString()).apply();toast("Saved")}
            else go(b[n])
        }.setNegativeButton("Close",null).show()
    }
    private fun looksLikeVideo(url: String): Boolean {
        val path = Uri.parse(url).path?.lowercase() ?: url.lowercase()
        return listOf(".mp4", ".m4v", ".webm", ".mov", ".3gp", ".mkv", ".mp3", ".m4a").any { path.contains(it) }
    }

    private fun showVideoQualityOptions(fallbackUrl: String?) {
        val options = pageVideoSources.toMutableList()
        if (!fallbackUrl.isNullOrBlank() && fallbackUrl.startsWith("http") &&
            options.none { it.first == fallbackUrl }) {
            options.add(fallbackUrl to guessQuality(fallbackUrl))
        }
        if (options.isEmpty()) {
            toast("This page does not expose a direct video file or selectable qualities")
            return
        }
        val labels = options.map { (url, label) ->
            val safeLabel = if (label.isBlank()) guessQuality(url) else label
            "$safeLabel  •  ${Uri.parse(url).lastPathSegment ?: "video"}"
        }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose available video quality")
            .setItems(labels) { _, which ->
                val (url, quality) = options[which]
                val name = URLUtil.guessFileName(url, null, "video/mp4")
                AlertDialog.Builder(this).setTitle("Download $quality?")
                    .setMessage("Only source variants exposed by this website are listed. DRM-protected or hidden adaptive streams may not be downloadable.")
                    .setPositiveButton("Download") { _, _ -> download(url, name, web.settings.userAgentString) }
                    .setNegativeButton("Cancel", null).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun guessQuality(url: String): String {
        val match = Regex("(2160|1440|1080|720|480|360)p?", RegexOption.IGNORE_CASE).find(url)
        return match?.value ?: "Available video"
    }

    private fun askDownload(url:String,ua:String?,cd:String?,mime:String?){
        if(!url.startsWith("http")){toast("Direct file link not available");return}
        val name=URLUtil.guessFileName(url,cd,mime)
        AlertDialog.Builder(this).setTitle("Download with ABH?")
            .setMessage("$name\n\nABH can download direct files provided by the website. It cannot create quality versions that the website does not expose.")
            .setPositiveButton("Download"){_,_->download(url,name,ua)}.setNegativeButton("Cancel",null).show()
    }
    private fun download(url:String,name:String,ua:String?){
        try{
            val r=DownloadManager.Request(Uri.parse(url)).setTitle(name).setDescription("ABH Downloader")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"ABH Downloader/$name")
            CookieManager.getInstance().getCookie(url)?.let{r.addRequestHeader("Cookie",it)}
            ua?.let{r.addRequestHeader("User-Agent",it)}
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r);toast("Download started");downloads()
        }catch(e:Exception){toast("Download error: ${e.message}")}
    }
    private fun downloads(){
        val dm=getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val lines=mutableListOf<String>();val c=dm.query(DownloadManager.Query())
        if(c!=null){while(c.moveToNext()){
            val n=c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE))?:"File"
            val st=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val mark=when(st){DownloadManager.STATUS_SUCCESSFUL->"✓✓";DownloadManager.STATUS_FAILED->"!";DownloadManager.STATUS_RUNNING,DownloadManager.STATUS_PENDING,DownloadManager.STATUS_PAUSED->"↓";else->"…"}
            lines.add("$mark  $n")
        };c.close()}
        if(lines.isEmpty())lines.add("No downloads yet")
        AlertDialog.Builder(this).setTitle("Downloads • ✓✓ completed").setItems(lines.toTypedArray()){_,_->}.setPositiveButton("OK",null).show()
    }
    private fun more(){
        val opts=arrayOf("Desktop mode: ${if(desktop)"ON" else "OFF"}","Save bookmark","Settings / limitations","About")
        AlertDialog.Builder(this).setTitle("More").setItems(opts){_,n->when(n){
            0->{
                desktop=!desktop
                web.settings.userAgentString=if(desktop)
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
                else
                    WebSettings.getDefaultUserAgent(this)
                web.settings.loadWithOverviewMode=desktop
                web.settings.useWideViewPort=true
                web.settings.setSupportZoom(true)
                web.settings.builtInZoomControls=true
                web.settings.displayZoomControls=false
                web.reload()
                toast("Desktop mode ${if(desktop)"ON" else "OFF"}")
            }
            1->{val b=saved();val u=web.url?: "";if(u.isNotBlank()&&!b.contains(u))b.add(u);prefs.edit().putString("bookmarks",JSONArray(b).toString()).apply();toast("Bookmark saved")}
            2->AlertDialog.Builder(this).setTitle("Settings & limitations").setMessage("Downloads are saved in Download/ABH Downloader.\n\nYouTube videos cannot be downloaded through ordinary WebView links. Use YouTube's official offline feature. Quality choices are possible only when a site supplies separate quality URLs. A website's ordinary navigation link is not a downloadable folder. Recursive folder download only works where the site exposes a public directory listing. DRM-protected and hidden adaptive video streams are not supported.").setPositiveButton("OK",null).show()
            3->AlertDialog.Builder(this).setMessage("ABH Downloader 2.0\nClean browser • Tabs • Bookmarks • Downloads").setPositiveButton("OK",null).show()
        }}.show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onBackPressed(){if(web.canGoBack())web.goBack() else super.onBackPressed()}
}
