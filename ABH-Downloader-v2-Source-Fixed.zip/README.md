# ABH Downloader 2.0
Redesigned Android WebView browser starter project.

Implemented: custom ABH dark/blue interface, launcher icon artwork, web search/address bar, basic multiple tabs and tab switcher, bookmarks, direct-file downloads, download list with ✓✓ on completed downloads, long-press direct link/image actions, desktop user-agent toggle, settings/about.

Build: upload the CONTENTS of this folder to the root of a GitHub repository (not this ZIP), commit to main, open Actions and run Build ABH Downloader APK, then download artifact ABH-Downloader-APK-v2.

Honest limitations: YouTube does not expose ordinary downloadable media URLs to WebView; this app does not bypass YouTube protections or DRM. Use YouTube's official offline feature. Quality selection requires sites to expose separate direct quality URLs and is not implemented here. Generic recursive website-folder downloads are not implemented because many sites do not expose real folder listings. This is a functional starter browser, not a production browser.
